function in = localResetFcn(in)

% randomize reference signal
% blk = sprintf('rlsuspension/road profile');
% road_amp = 3*randn + 10;
% 
% in = setBlockParameter(in,blk,'Amplitude',num2str(road_amp));

fprintf("new eposide is starting")
end